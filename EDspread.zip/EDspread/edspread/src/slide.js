
  
/*
<html>
  <title>

  </title>
    <body>
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="C:\Users\dashm\OneDrive\Desktop\EDspread-master\edspread\src\aset\p1.jpg" style="width:100%"/>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="C:\Users\dashm\OneDrive\Desktop\EDspread-master\edspread\src\aset\p2.jpg"/>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="C:\Users\dashm\OneDrive\Desktop\EDspread-master\edspread\src\aset\p3.jpg"/>
</div>

<a class="prev" onclick="plusSlides(-1)"> </a>
<a class="next" onclick="plusSlides(1)"></a>

</div>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>
</body>
<script>
let slideIndex = 1;
            showSlides(slideIndex);
            
            function plusSlides(n) {
              showSlides(slideIndex += n);
            }
            
            function currentSlide(n) {
              showSlides(slideIndex = n);
            }
            
           export default  function showSlides(n) {
              let i;
              let slides = document.getElementsByClassName("mySlides");
              let dots = document.getElementsByClassName("dot");
              if (n > slides.length) {slideIndex = 1}    
              if (n < 1) {slideIndex = slides.length}
              for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";  
              }
              for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
              }
              slides[slideIndex-1].style.display = "block";  
              dots[slideIndex-1].className += " active";
            }
            </script>
</html>
*/

import React from 'react';
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'

const slideImages = [
  {
    url: '/aset/p1.jpg',
    caption: 'Slide 1'
  },
  {
    url: '/aset/p2.jpg',
    caption: 'Slide 2'
  },
  {
    url: '/aset/p3.jpg',
    caption: 'Slide 3'
  },
];

export  function Slideshow() {
    return (
      <div className="slide-container">
        <Slide>
         {slideImages.map((slideImage, index)=> (
            <div className="each-slide" key={index}>
              <div style={{'backgroundImage': `url(${slideImage.url})`}}>
                <span>{slideImage.caption} </span>
              </div>
            </div>
          ))} 
        </Slide>
      </div>
    )
}