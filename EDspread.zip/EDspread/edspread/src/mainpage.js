import React from 'react'
import { Box, Typography, IconButton, AppBar, Toolbar, Button, Paper, Skeleton, Card, CardContent, Grid } from '@mui/material'
import { Link, useNavigate } from 'react-router-dom'
import MenuIcon from '@mui/icons-material/Menu';
import axios from 'axios';

import image from './aset/p1.jpg'
import { green } from '@mui/material/colors';

import {Slideshow} from './slide.js'



function MainPage() {


  const [apiConf, setapiConf] = React.useState(false)
  const [admin, setAdmin] = React.useState(false)
  const navigate = useNavigate()
  React.useEffect(() => {
    axios.get('http://localhost:5000/status')
      .then((result) => {
        if (result.data.status)
          {setapiConf(true)
          if(result.data.user==='admin')
          {
            setAdmin(true)
          }
          }

        else
          navigate('/login')
      }).catch((err) => {

      });
  }, [])
  const [value, setValue] = React.useState([])
  // const[loading,setLoading]=React.useState(true)
  React.useEffect(() => {
    if(apiConf)
    {axios.get('http://localhost:5000/activity')
      .then((result) => {
        result = result.data
        if (result.status) {
          console.log(result);
          setValue(result.rows)
        }
        else {
          console.log(result);
          setValue([])
        }

      }).catch((err) => {

      });}
  }, [apiConf])

  function logout()
  {
      axios.post('http://localhost:5000/logout')
      .then((result) => {
          result=result.data
          if(result.status)
          {
              console.log('logged out succesfully');
              navigate('/login')
          }
      }).catch((err) => {
          
      });
  }

            
  return (
    
    apiConf ?<>
    
      <Box sx={{position:'fixed',width:'100%'}}>
        <Typography variant='h4' component='div'
          sx={{
            color:'whitesmoke',
            fontFamily: 'Gemunu Libre, sans-serif',
            textAlign: 'center'
          }}
        >WELCOME
        <marquee> CHAITANYA BHARATHI INSTITUTE OF TECHNOLOGY, Hyderabad </marquee></Typography>


        <Box className='navBar'>
          <AppBar position="static" sx={{
            backgroundColor: 'rgba(105, 111, 42, 0)',


          }}>
            <Toolbar>
              
              <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                
              </Typography>

           { admin?  <Link to='/admin'>  <Button sx={{ color: 'white' }}> Admin</Button></Link>:null}
              <Link to='/discus'>  <Button sx={{ color: 'white' }}> Group Chat</Button></Link>
               
              <Button onClick={logout} sx={{ color: 'white' }}>Log Out</Button>
            </Toolbar>
          </AppBar>
          <Box display='flex' justifyContent='space-evenly'>

            { <Slideshow/>
            
            
            
            
            /* {
        loading?
        <Skeleton sx={{width:'500px',height:'500px'}} variant='rectangle' animation='wave'/>:
        
        <img className='mainimg' onLoad={()=>(setLoading(false))}  src='https://source.unsplash.com/random/1500x1500'></img>} 

            <img className='mainimg' src={image}></img> */
  
            }


            <Paper sx={{ width: '500px', backgroundColor:'rgba(0,0,0,0)' }} 



            >
              
              <Grid container
                flexGrow={1}
                sx={
                  {
                    '& div:nth-of-type(even) div div div':
                    {
                      backgroundColor: 'rgb(168, 232, 144)'
                    },
                    '& div:nth-of-type(odd) div div ':
                    {
                      /* backgroundColor: 'rgb(116, 159, 130)'*/
                      backgroundColor : green
                    }
                  }
                }
              >
                {value.map((item) => (
                  <Grid item flexGrow={1}>
                    <Box  >
                      <Card sx={{ margin: '2px', width: 'auto' }} variant='outlined'>
                        <CardContent>
                          <Typography variant='h6' component='div' width='auto'>{item.act}</Typography>
                        </CardContent>
                      </Card>
                    </Box>
                  </Grid>
                ))}
              </Grid>


            </Paper>
          </Box>
        </Box>
      </Box>
    
    </>:null
  )

}

export default MainPage